#Kacper Kucharski
from PIL import Image

max = 1e5
min = 1e-7
eps = 1e-5
iterations=40

xa=-1
xb= 1
ya=-1
yb= 1

def f(z): return z**5+1     # f(z) = z^5 + 1
def df(z): return 5*z**4    # f`(z) = 5*z^4

def ifinres(res1,res2):
    for i in res2:
        if abs(res1-i)<1e-3:
            return False
    return True

def newton(z):
    for i in range(iterations):
        h = f(z)/df(z)
        if abs(f(z))<min or abs(f(z))>max :return None
        if abs(h)<eps:return z
        z = z - h
    return None

# Z(n+1) = Z(n) - w(Zn)/w`(Zn)

img = Image.new("RGB",(512,512),(255,255,255))
results = []
y=0
while y<512:
    x=0
    zy = ya + y*(yb-ya)/(511)
    while x<512:
        zx = xa + x*(xb-xa)/(511)
        result = newton(complex(zx,zy))          
        if result and ifinres(result,results):
            results.append(result)                   
        if result:                
            img.putpixel((x,y),(255,140,0))
        if not result:
            img.putpixel((x,y),(176,224,235))  
        x+=1
    y+=1
    img.save("Image", "PNG")




